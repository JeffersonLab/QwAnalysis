

typedef double *vektor;

