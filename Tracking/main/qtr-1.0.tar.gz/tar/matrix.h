#include "vektor.h"

typedef double **matrix;

