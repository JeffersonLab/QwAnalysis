#include <iostream>
using namespace std;

int Row_Mult(int *xa);
double *blah(double *matrix);


int main(void){

double A[4][4],B[4][4];
int i,j,k,l;
//initialize B
double *Ap = &B[0][0];






for(i=0;i<4;i++){
  for(j=0;j<4;j++){
    if(i==j)B[i][j]=j;
    else B[i][j]=0;
  }
}

double *Aq = Ap;
for(i=0;i<4;i++){
  for(j=0;j<4;j++){
    cerr << *(Aq++) << " ";
  }
  cerr << endl;
}
blah(Ap);
Aq = Ap;
for(i=0;i<4;i++){
  for(j=0;j<4;j++){
    cerr << *(Aq++) << " ";
  }
  cerr << endl;
}




return 0;

}


int Row_Mult(int *xa){


return 1;
}

double *blah(double *matrix){
int i,j;
double *x = matrix;
for(i=0;i<4;i++){
  for(j=0;j<4;j++){
    *x = i;
    x++;
  }
}

return matrix;
}
