#ifndef QOPTIONS_H
#define QOPTIONS_H

/*! \brief Qoptions is a generic ascii read-in program for handling
program options.
*/
class Qoptions{
public:
Qoptions();
void Get(char *optionsfile);

private:


};


#endif
