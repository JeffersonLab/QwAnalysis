#include "treedo.h"
#include "Qset.h"
#include "Qevent.h"
#include "Qoptions.h"
#include <iostream>
using namespace std;

#define NDetMax 1010
//Temporary global variables for sub-programs
bool bWriteGlobal = false;
int iEvent = 0;
TreeLine  *trelin;
int trelinanz;
Det *rcDETRegion[2][3][4];
treeregion *rcTreeRegion[2][3][4][4];
Det rcDET[NDetMax];
Options opt;


int main(void){


	Qset qset;
	qset.FillDetec("qweak.geo");
	cerr << "Detector Geometry Loaded" << endl;//R3,R2

	Qoptions qoptions;
	qoptions.Get("qweak.options");
	cerr << "Options Loaded" << endl;//R3,R2

	tree thetree;
	thetree.rcInitTree();
	cerr << "Track Pattern Database Loaded" << endl;//R3,R2

///event loop goes here
 
	Qevent qevent;
	qevent.Open("qweak.event");
	treedo Treedo;//R3 needs debugging in the 3-D fit
	iEvent = qevent.GetEvent();
	while(iEvent>0){
		Treedo.rcTreeDo(iEvent);
		iEvent = qevent.GetEvent();//R3,R2
	}
	cerr << "Good :" << Treedo.ngood << endl;
	cerr << "Bad  :" << Treedo.nbad << endl;


	
///and ends here

	return 0;
}

/*! \file main.cc -------------------------
\brief
This is the main program which simply executes a series of commands
*/
